extends Camera3D

# -----------------------------------------
# MOVEMENT SETTINGS
# -----------------------------------------
@export var speed: float = 10.0
@export var smoothness: float = 8.0

var velocity: Vector3 = Vector3.ZERO

# -----------------------------------------
func _process(delta):

	var input_dir = Vector3.ZERO

	# LEFT / RIGHT
	if Input.is_action_pressed("ui_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("ui_right"):
		input_dir.x += 1

	# UP / DOWN (forward & backward)
	if Input.is_action_pressed("ui_up"):
		input_dir.z -= 1
	if Input.is_action_pressed("ui_down"):
		input_dir.z += 1

	# Normalize for consistent speed
	input_dir = input_dir.normalized()

	# Smooth movement
	velocity = velocity.lerp(input_dir * speed, smoothness * delta)

	# Apply movement
	translate(velocity * delta)
