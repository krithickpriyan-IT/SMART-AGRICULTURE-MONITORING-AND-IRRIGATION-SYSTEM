import json
import matplotlib.pyplot as plt
from datetime import datetime


def plot_graph(metric):

    with open("farm_data.json") as f:
        data = json.load(f)

    history = data["field_1"]["history"]

    if len(history) == 0:
        print("No data")
        return

    # ✅ Values
    values = [entry.get(metric, 0) for entry in history]

    # ✅ DATE + TIME FORMAT
    times = [
        datetime.fromtimestamp(entry["timestamp"]).strftime("%d-%m %H:%M:%S")
        for entry in history
    ]

    # OPTIONAL: show only last 10 points (clean graph)
    times = times[-10:]
    values = values[-10:]

    # ✅ Plot
    plt.figure()
    plt.plot(times, values, marker='o')

    plt.title(metric.upper() + " GRAPH")
    plt.xlabel("Date & Time")
    plt.ylabel(metric)

    plt.xticks(rotation=45)
    plt.tight_layout()

    plt.show()