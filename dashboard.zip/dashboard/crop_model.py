import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib

data = {
    "temperature": [25,30,35,28,32,27,33,29],
    "humidity": [60,70,50,80,65,75,55,68],
    "soil_ph": [7.0,6.5,6.0,5.5,6.8,6.2,7.2,6.4],
    "crop": ["Maize","Rice","Millet","Rice","Groundnut","Rice","Maize","Groundnut"]
}

df = pd.DataFrame(data)

X = df[["temperature","humidity","soil_ph"]]
y = df["crop"]

model = DecisionTreeClassifier()
model.fit(X,y)

joblib.dump(model,"model.pkl")

print("✅ Model trained & saved as model.pkl")