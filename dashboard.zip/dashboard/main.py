import json
import pandas as pd
import joblib

from kivy.lang import Builder
from kivy.clock import Clock
from kivy.core.text import LabelBase

from kivymd.app import MDApp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDFlatButton

from graph_screen import plot_graph


class SmartFarmApp(MDApp):

    def build(self):

        # ✅ Register Tamil font
        LabelBase.register(
            name="TamilFont",
            fn_regular="NotoSansTamil-Regular.ttf"
        )

        self.model = joblib.load("model.pkl")
        self.lang = "en"

        self.theme_cls.theme_style = "Light"

        self.root = Builder.load_file("ui.kv")

        Clock.schedule_interval(self.update_data, 2)

        return self.root

    # ---------------- DATA ----------------
    def update_data(self, dt):
        try:
            with open("farm_data.json") as f:
                data = json.load(f)

            if "field_1" not in data:
                return

            d = data["field_1"]

            input_data = pd.DataFrame({
                "temperature": [d.get("temperature", 0)],
                "humidity": [d.get("humidity", 0)],
                "soil_ph": [d.get("soil_ph", 0)]
            })

            crop = self.model.predict(input_data)[0]

            weather_map = {
                "sunny": "வெயில்",
                "rain": "மழை",
                "cloudy": "மேகம்"
            }

            if self.lang == "en":

                self.root.ids.title.text = "Smart Agriculture Dashboard"
                self.root.ids.temp.text = f"Temperature: {d.get('temperature', 0)} °C"
                self.root.ids.hum.text = f"Humidity: {d.get('humidity', 0)} %"
                self.root.ids.ph.text = f"Soil pH: {d.get('soil_ph', 0)}"
                self.root.ids.water.text = f"Water Used: {d.get('water_used', 0)} L"

                self.root.ids.weather.text = f"Weather: {d.get('weather', 'sunny')}"
                self.root.ids.crop.text = f"Crop: {crop}"

            else:

                self.root.ids.title.text = "ஸ்மார்ட் வேளாண்மை டாஷ்போர்டு"
                self.root.ids.temp.text = f"வெப்பநிலை: {d.get('temperature', 0)} °C"
                self.root.ids.hum.text = f"ஈரப்பதம்: {d.get('humidity', 0)} %"
                self.root.ids.ph.text = f"மண் pH: {d.get('soil_ph', 0)}"
                self.root.ids.water.text = f"நீர் பயன்பாடு: {d.get('water_used', 0)} L"

                weather_ta = weather_map.get(d.get("weather", "sunny"), "வெயில்")
                self.root.ids.weather.text = f"வானிலை: {weather_ta}"
                self.root.ids.crop.text = f"பயிர்: {crop}"

        except Exception as e:
            print("Error:", e)

    # ---------------- LANGUAGE ----------------
    def switch_lang(self):

        widgets = [
            "title", "temp", "hum", "ph", "water",
            "weather", "crop",
            "lang_btn", "graph_btn",
            "pump_on_btn", "pump_off_btn"
        ]

        if self.lang == "en":
            self.lang = "ta"

            self.root.ids.lang_btn.text = "மொழி"
            self.root.ids.graph_btn.text = "வரைபடம்"
            self.root.ids.pump_on_btn.text = "ஆன்"
            self.root.ids.pump_off_btn.text = "ஆஃப்"

            for w in widgets:
                self.root.ids[w].font_name = "TamilFont"

        else:
            self.lang = "en"

            self.root.ids.lang_btn.text = "Language"
            self.root.ids.graph_btn.text = "Graph"
            self.root.ids.pump_on_btn.text = "ON"
            self.root.ids.pump_off_btn.text = "OFF"

            for w in widgets:
                self.root.ids[w].font_name = "Roboto"

    # ---------------- DARK MODE ----------------
    def toggle_dark_mode(self):
        self.theme_cls.theme_style = (
            "Dark" if self.theme_cls.theme_style == "Light" else "Light"
        )

    # ---------------- PUMP ----------------
    def pump_on(self):
        self.update_json("manual_mode", True)
        self.update_json("sprinkler_on", True)

    def pump_off(self):
        self.update_json("manual_mode", True)
        self.update_json("sprinkler_on", False)

    def update_json(self, key, value):
        try:
            with open("farm_data.json") as f:
                data = json.load(f)

            if "field_1" not in data:
                data["field_1"] = {}

            data["field_1"][key] = value

            with open("farm_data.json", "w") as f:
                json.dump(data, f, indent=4)

        except Exception as e:
            print("JSON Error:", e)

    # ---------------- GRAPH MENU ----------------
    def open_graph_menu(self, button):

        if self.lang == "en":
            options = [
                ("Temperature", "temperature"),
                ("Humidity", "humidity"),
                ("Soil pH", "soil_ph"),
                ("Water Used", "water_used"),
            ]
            title = "Select Graph"
        else:
            options = [
                ("வெப்பநிலை", "temperature"),
                ("ஈரப்பதம்", "humidity"),
                ("மண் pH", "soil_ph"),
                ("நீர் பயன்பாடு", "water_used"),
            ]
            title = "வரைபடம் தேர்வு"

        layout = MDBoxLayout(
            orientation="vertical",
            spacing=10,
            padding=10,
            size_hint_y=None
        )
        layout.bind(minimum_height=layout.setter("height"))

        for text, metric in options:
            btn = MDFlatButton(
                text=text,
                size_hint_y=None,
                height=50,
                on_release=lambda x, m=metric: self.select_graph(m)
            )

            if self.lang == "ta":
                btn.font_name = "TamilFont"

            layout.add_widget(btn)

        self.dialog = MDDialog(
            title=title,
            type="custom",
            content_cls=layout
        )

        # ✅ FIX TITLE FONT (Tamil)
        if self.lang == "ta":
            self.dialog.ids.title.font_name = "TamilFont"

        self.dialog.open()

    # ---------------- GRAPH SELECT ----------------
    def select_graph(self, metric):
        self.dialog.dismiss()
        plot_graph(metric)


SmartFarmApp().run()
